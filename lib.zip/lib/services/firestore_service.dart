import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/ad_model.dart';
import '../models/user_model.dart';
import '../models/business_model.dart';

class FirestoreService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ========== USER İŞLEMLERİ ==========
  
  // Kullanıcı oluştur
  static Future<void> createUser(UserModel user) async {
    await _db.collection('users').doc(user.id).set(user.toMap());
  }

  // Kullanıcı getir
  static Future<UserModel?> getUser(String userId) async {
    final doc = await _db.collection('users').doc(userId).get();
    if (!doc.exists) return null;
    return UserModel.fromFirestore(doc);
  }

  // Kullanıcı güncelle
  static Future<void> updateUser(String userId, Map<String, dynamic> data) async {
    await _db.collection('users').doc(userId).update(data);
  }

  // Token ekle/çıkar
  static Future<void> updateUserTokens(String userId, int amount) async {
    await _db.collection('users').doc(userId).update({
      'tokenBalance': FieldValue.increment(amount),
    });
  }

  // Rozet ekle
  static Future<void> addBadgeToUser(String userId, String badge) async {
    await _db.collection('users').doc(userId).update({
      'badges': FieldValue.arrayUnion([badge]),
    });
  }

  // ========== AD (İLAN) İŞLEMLERİ ==========
  
  // İlan oluştur
  static Future<String> createAd(AdModel ad) async {
    final docRef = await _db.collection('ads').add(ad.toMap());
    
    // Kullanıcının toplam ilan sayısını artır
    await _db.collection('users').doc(ad.userId).update({
      'totalAds': FieldValue.increment(1),
    });
    
    return docRef.id;
  }

  // İlan getir
  static Future<AdModel?> getAd(String adId) async {
    final doc = await _db.collection('ads').doc(adId).get();
    if (!doc.exists) return null;
    return AdModel.fromFirestore(doc);
  }

  // İlan güncelle
  static Future<void> updateAd(String adId, Map<String, dynamic> data) async {
    data['updatedAt'] = FieldValue.serverTimestamp();
    await _db.collection('ads').doc(adId).update(data);
  }

  // İlan sil
  static Future<void> deleteAd(String adId, String userId) async {
    await _db.collection('ads').doc(adId).update({
      'status': 'deleted',
      'updatedAt': FieldValue.serverTimestamp(),
    });
    
    // Kullanıcının toplam ilan sayısını azalt
    await _db.collection('users').doc(userId).update({
      'totalAds': FieldValue.increment(-1),
    });
  }

  // İlan görüntülenme sayısını artır
  static Future<void> incrementAdViews(String adId) async {
    await _db.collection('ads').doc(adId).update({
      'viewCount': FieldValue.increment(1),
    });
  }

  // Aktif ilanları getir (ana sayfa)
  static Stream<List<AdModel>> getActiveAds({int limit = 20}) {
    return _db
        .collection('ads')
        .where('status', isEqualTo: 'active')
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => AdModel.fromQuery(doc)).toList());
  }

  // Kategoriye göre ilanları getir
  static Stream<List<AdModel>> getAdsByCategory(String category, {int limit = 20}) {
    return _db
        .collection('ads')
        .where('status', isEqualTo: 'active')
        .where('category', isEqualTo: category)
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => AdModel.fromQuery(doc)).toList());
  }

  // Şehre göre ilanları getir
  static Stream<List<AdModel>> getAdsByCity(String city, {int limit = 20}) {
    return _db
        .collection('ads')
        .where('status', isEqualTo: 'active')
        .where('city', isEqualTo: city)
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => AdModel.fromQuery(doc)).toList());
  }

  // Kullanıcının ilanlarını getir
  static Stream<List<AdModel>> getUserAds(String userId) {
    return _db
        .collection('ads')
        .where('userId', isEqualTo: userId)
        .where('status', isEqualTo: 'active')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => AdModel.fromQuery(doc)).toList());
  }

  // İlan ara (başlık ve açıklamada)
  static Future<List<AdModel>> searchAds(String query, {String? city}) async {
    Query adsQuery = _db
        .collection('ads')
        .where('status', isEqualTo: 'active');

    if (city != null && city.isNotEmpty) {
      adsQuery = adsQuery.where('city', isEqualTo: city);
    }

    final snapshot = await adsQuery.get();
    
    final lowerQuery = query.toLowerCase();
    return snapshot.docs
        .map((doc) => AdModel.fromQuery(doc))
        .where((ad) =>
            ad.title.toLowerCase().contains(lowerQuery) ||
            ad.description.toLowerCase().contains(lowerQuery))
        .toList();
  }

  // ========== BUSINESS (DÜKKAN) İŞLEMLERİ ==========
  
  // Dükkan oluştur
  static Future<String> createBusiness(BusinessModel business) async {
    final docRef = await _db.collection('businesses').add(business.toMap());
    
    // Kullanıcıyı business hesabı yap
    await _db.collection('users').doc(business.ownerId).update({
      'isBusinessAccount': true,
    });
    
    return docRef.id;
  }

  // Dükkan getir
  static Future<BusinessModel?> getBusiness(String businessId) async {
    final doc = await _db.collection('businesses').doc(businessId).get();
    if (!doc.exists) return null;
    return BusinessModel.fromFirestore(doc);
  }

  // Kullanıcının dükkanını getir
  static Future<BusinessModel?> getBusinessByOwner(String ownerId) async {
    final snapshot = await _db
        .collection('businesses')
        .where('ownerId', isEqualTo: ownerId)
        .limit(1)
        .get();
    
    if (snapshot.docs.isEmpty) return null;
    return BusinessModel.fromFirestore(snapshot.docs.first);
  }

  // Dükkan güncelle
  static Future<void> updateBusiness(String businessId, Map<String, dynamic> data) async {
    data['updatedAt'] = FieldValue.serverTimestamp();
    await _db.collection('businesses').doc(businessId).update(data);
  }

  // Dükkan görüntülenme sayısını artır
  static Future<void> incrementBusinessViews(String businessId) async {
    await _db.collection('businesses').doc(businessId).update({
      'totalViews': FieldValue.increment(1),
    });
  }

  // Aktif dükkanları getir
  static Stream<List<BusinessModel>> getActiveBusinesses({int limit = 20}) {
    return _db
        .collection('businesses')
        .where('isActive', isEqualTo: true)
        .orderBy('rating', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => BusinessModel.fromFirestore(doc)).toList());
  }

  // Kategoriye göre dükkanları getir
  static Stream<List<BusinessModel>> getBusinessesByCategory(String category) {
    return _db
        .collection('businesses')
        .where('isActive', isEqualTo: true)
        .where('category', isEqualTo: category)
        .orderBy('rating', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => BusinessModel.fromFirestore(doc)).toList());
  }

  // ========== FAVORİ İŞLEMLERİ ==========
  
  // Favorilere ekle
  static Future<void> addToFavorites(String userId, String adId) async {
    await _db
        .collection('users')
        .doc(userId)
        .collection('favorites')
        .doc(adId)
        .set({
      'adId': adId,
      'addedAt': FieldValue.serverTimestamp(),
    });
  }

  // Favorilerden çıkar
  static Future<void> removeFromFavorites(String userId, String adId) async {
    await _db
        .collection('users')
        .doc(userId)
        .collection('favorites')
        .doc(adId)
        .delete();
  }

  // Favorileri getir
  static Stream<List<AdModel>> getFavoriteAds(String userId) async* {
    final favoritesStream = _db
        .collection('users')
        .doc(userId)
        .collection('favorites')
        .orderBy('addedAt', descending: true)
        .snapshots();

    await for (var snapshot in favoritesStream) {
      final adIds = snapshot.docs.map((doc) => doc.id).toList();
      
      if (adIds.isEmpty) {
        yield [];
        continue;
      }

      final ads = <AdModel>[];
      for (var adId in adIds) {
        final ad = await getAd(adId);
        if (ad != null && ad.isActive) {
          ads.add(ad);
        }
      }
      
      yield ads;
    }
  }

  // İlan favoride mi?
  static Future<bool> isAdFavorite(String userId, String adId) async {
    final doc = await _db
        .collection('users')
        .doc(userId)
        .collection('favorites')
        .doc(adId)
        .get();
    
    return doc.exists;
  }
}
