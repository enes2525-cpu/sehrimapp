import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:sehrimapp/models/user_model.dart';
import 'package:sehrimapp/screens/my_ads/my_ads_screen.dart';
import 'package:sehrimapp/screens/favorites/favorites_screen.dart';
import 'package:sehrimapp/screens/appointments/appointments_screen.dart';
import 'package:sehrimapp/screens/shop/shop_management_screen.dart';
import 'package:sehrimapp/screens/profile/edit_profile_screen.dart';
import 'package:sehrimapp/screens/auth/login_screen.dart';
import 'package:sehrimapp/screens/token/token_wallet_screen.dart';
import 'package:sehrimapp/screens/conversations/conversations_screen.dart';
import 'dart:io';

class ProfileTab extends StatefulWidget {
  const ProfileTab({Key? key}) : super(key: key);

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  UserModel? _userModel;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final user = FirebaseAuth.instance.currentUser;
    
    if (user == null) {
      setState(() {
        _loading = false;
      });
      return;
    }

    try {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();

      if (doc.exists && mounted) {
        setState(() {
          _userModel = UserModel.fromFirestore(doc);
          _loading = false;
        });
      }
    } catch (e) {
      setState(() {
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    if (_loading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (user == null) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.person_outline,
                size: 100,
                color: Colors.grey,
              ),
              const SizedBox(height: 16),
              const Text(
                'Giriş yapmanız gerekiyor',
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const LoginScreen(),
                    ),
                  );
                },
                child: const Text('Giriş Yap'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      body: ListView(
        children: [
          // Profil Header
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor,
            ),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.white,
                  child: _userModel?.photoUrl != null
                      ? (_userModel!.photoUrl!.startsWith('/')
                          ? Image.file(
                              File(_userModel!.photoUrl!),
                              fit: BoxFit.cover,
                            )
                          : Image.network(
                              _userModel!.photoUrl!,
                              fit: BoxFit.cover,
                            ))
                      : const Icon(
                          Icons.person,
                          size: 50,
                          color: Colors.grey,
                        ),
                ),
                const SizedBox(height: 12),
                Text(
                  _userModel?.name ?? user.email ?? 'Kullanıcı',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  user.email ?? '',
                  style: const TextStyle(
                    color: Colors.white70,
                  ),
                ),
                if (_userModel?.city != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    _userModel!.city!,
                    style: const TextStyle(
                      color: Colors.white70,
                    ),
                  ),
                ],
                if (_userModel?.isBusinessAccount ?? false) ...[
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.orange,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text(
                      'İşletme Hesabı',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),

          // İstatistikler
          Container(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStatItem(
                  Icons.inventory,
                  'İlanlar',
                  '${_userModel?.totalAds ?? 0}',
                ),
                _buildStatItem(
                  Icons.favorite,
                  'Favoriler',
                  '0',
                ),
                _buildStatItem(
                  Icons.star,
                  'Puan',
                  '5.0',
                ),
              ],
            ),
          ),

          const Divider(),

          // Profil Düzenle
          ListTile(
            leading: const Icon(Icons.edit),
            title: const Text('Profil Düzenle'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const EditProfileScreen(),
                ),
              );
            },
          ),

          // Token Cüzdanı
          ListTile(
            leading: const Icon(Icons.monetization_on),
            title: const Text('Token Cüzdanı'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const TokenWalletScreen(),
                ),
              );
            },
          ),

          // Mesajlarım
          ListTile(
            leading: const Icon(Icons.message),
            title: const Text('Mesajlarım'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ConversationsScreen(),
                ),
              );
            },
          ),

          // İlanlarım
          ListTile(
            leading: const Icon(Icons.inventory_2),
            title: const Text('İlanlarım'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const MyAdsScreen(),
                ),
              );
            },
          ),

          // Favorilerim
          ListTile(
            leading: const Icon(Icons.favorite),
            title: const Text('Favorilerim'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const FavoritesScreen(),
                ),
              );
            },
          ),

          // Randevularım
          ListTile(
            leading: const Icon(Icons.calendar_today),
            title: const Text('Randevularım'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const AppointmentsScreen(),
                ),
              );
            },
          ),

          if (_userModel?.isBusinessAccount ?? false) ...[
            const Divider(),
            ListTile(
              leading: const Icon(Icons.store),
              title: const Text('Dükkanım'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ShopManagementScreen(),
                  ),
                );
              },
            ),
          ],

          const Divider(),

          // Ayarlar
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('Ayarlar'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              // Ayarlar ekranı
            },
          ),

          // Yardım
          ListTile(
            leading: const Icon(Icons.help),
            title: const Text('Yardım'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              // Yardım ekranı
            },
          ),

          // Çıkış Yap
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text(
              'Çıkış Yap',
              style: TextStyle(color: Colors.red),
            ),
            onTap: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Çıkış Yap'),
                  content: const Text('Çıkış yapmak istediğinize emin misiniz?'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context, false),
                      child: const Text('İptal'),
                    ),
                    TextButton(
                      onPressed: () => Navigator.pop(context, true),
                      child: const Text('Çıkış Yap'),
                    ),
                  ],
                ),
              );

              if (confirm == true) {
                await FirebaseAuth.instance.signOut();
                if (mounted) {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const LoginScreen(),
                    ),
                  );
                }
              }
            },
          ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildStatItem(IconData icon, String label, String value) {
    return Column(
      children: [
        Icon(icon, color: Theme.of(context).primaryColor),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 12,
          ),
        ),
      ],
    );
  }
}