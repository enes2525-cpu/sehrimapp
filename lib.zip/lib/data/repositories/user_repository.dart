import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/utils/result.dart';
import '../../core/constants/app_constants.dart';
import '../models/user_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';

/// Kullanıcı işlemlerini yöneten Repository
/// User CRUD + Token + Settings + Stats
class UserRepository {
  final FirestoreService _firestoreService;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  UserRepository({
    FirestoreService? firestoreService,
  }) : _firestoreService = firestoreService ?? FirestoreService();

  // ========== KULLANICI İŞLEMLERİ ==========

  /// Kullanıcı bilgilerini getir
  Future<Result<UserModel>> getUser(String userId) async {
    try {
      final doc = await _db
          .collection(AppConstants.collectionUsers)
          .doc(userId)
          .get();

      if (!doc.exists) {
        return Result.error('Kullanıcı bulunamadı');
      }

      final user = UserModel.fromFirestore(doc);
      return Result.success(user);
    } catch (e) {
      return Result.error('Kullanıcı yüklenirken hata: ${e.toString()}');
    }
  }

  /// Mevcut kullanıcıyı getir
  Future<Result<UserModel>> getCurrentUser() async {
    try {
      final userId = AuthService.currentUserId;
      if (userId == null) {
        return Result.error('Giriş yapmalısınız');
      }

      return await getUser(userId);
    } catch (e) {
      return Result.error('Kullanıcı yüklenirken hata: ${e.toString()}');
    }
  }

  /// Kullanıcı bilgilerini güncelle
  Future<Result<void>> updateUser({
    required String userId,
    String? name,
    String? phone,
    String? photoUrl,
    String? bio,
    Map<String, dynamic>? settings,
  }) async {
    try {
      // Mevcut kullanıcı kontrolü
      final currentUserId = AuthService.currentUserId;
      if (currentUserId == null) {
        return Result.error('Giriş yapmalısınız');
      }

      // Yetki kontrolü
      if (currentUserId != userId) {
        return Result.error('Bu işlem için yetkiniz yok');
      }

      // Güncelleme verisi
      final updateData = <String, dynamic>{};
      
      if (name != null) updateData['name'] = name;
      if (phone != null) updateData['phone'] = phone;
      if (photoUrl != null) updateData['photoUrl'] = photoUrl;
      if (bio != null) updateData['bio'] = bio;
      if (settings != null) updateData['settings'] = settings;
      
      updateData['updatedAt'] = FieldValue.serverTimestamp();

      await _db.collection(AppConstants.collectionUsers).doc(userId).update(updateData);

      return Result.success(null);
    } catch (e) {
      return Result.error('Profil güncellenirken hata: ${e.toString()}');
    }
  }

  /// Profil fotoğrafı güncelle
  Future<Result<void>> updateProfilePhoto(String userId, String photoUrl) async {
    return await updateUser(userId: userId, photoUrl: photoUrl);
  }

  /// Biyografi güncelle
  Future<Result<void>> updateBio(String userId, String bio) async {
    return await updateUser(userId: userId, bio: bio);
  }

  /// Telefon güncelle
  Future<Result<void>> updatePhone(String userId, String phone) async {
    return await updateUser(userId: userId, phone: phone);
  }

  // ========== TOKEN İŞLEMLERİ ==========

  /// Token bakiyesini getir
  Future<Result<int>> getTokenBalance(String userId) async {
    try {
      final user = await getUser(userId);
      
      if (!user.isSuccess) {
        return Result.error(user.error ?? 'Kullanıcı bulunamadı');
      }

      return Result.success(user.data!.tokenBalance);
    } catch (e) {
      return Result.error('Token bakiyesi yüklenirken hata: ${e.toString()}');
    }
  }

  /// Mevcut kullanıcının token bakiyesi
  Future<Result<int>> getCurrentUserTokenBalance() async {
    final userId = AuthService.currentUserId;
    if (userId == null) {
      return Result.error('Giriş yapmalısınız');
    }
    return await getTokenBalance(userId);
  }

  /// Token bakiyesini güncelle (manuel - dikkatli kullan!)
  Future<Result<void>> updateTokenBalance(String userId, int newBalance) async {
    try {
      await _db.collection(AppConstants.collectionUsers).doc(userId).update({
        'tokenBalance': newBalance,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      return Result.success(null);
    } catch (e) {
      return Result.error('Token güncellenirken hata: ${e.toString()}');
    }
  }

  // ========== İSTATİSTİKLER ==========

  /// Kullanıcı istatistiklerini getir
  Future<Result<Map<String, dynamic>>> getUserStats(String userId) async {
    try {
      final user = await getUser(userId);
      if (!user.isSuccess) {
        return Result.error(user.error ?? 'Kullanıcı bulunamadı');
      }

      final userData = user.data!;

      // İlan sayısı
      final adsSnapshot = await _db
          .collection(AppConstants.collectionAds)
          .where('userId', isEqualTo: userId)
          .where('status', isEqualTo: 'active')
          .get();

      // Favori sayısı
      final favoritesSnapshot = await _db
          .collection(AppConstants.collectionUsers)
          .doc(userId)
          .collection('favorites')
          .get();

      // Post sayısı
      final postsSnapshot = await _db
          .collection(AppConstants.collectionPosts)
          .where('userId', isEqualTo: userId)
          .get();

      final stats = {
        'userId': userId,
        'name': userData.name,
        'email': userData.email,
        'photoUrl': userData.photoUrl,
        'tokenBalance': userData.tokenBalance,
        'totalAds': adsSnapshot.docs.length,
        'totalFavorites': favoritesSnapshot.docs.length,
        'totalPosts': postsSnapshot.docs.length,
        'followerCount': userData.followerCount ?? 0,
        'followingCount': userData.followingCount ?? 0,
        'rating': userData.rating,
        'totalRatings': userData.totalRatings ?? 0,
        'isBusinessAccount': userData.isBusinessAccount,
        'badges': userData.badges,
        'createdAt': userData.createdAt,
      };

      return Result.success(stats);
    } catch (e) {
      return Result.error('İstatistikler yüklenirken hata: ${e.toString()}');
    }
  }

  /// Mevcut kullanıcının istatistikleri
  Future<Result<Map<String, dynamic>>> getCurrentUserStats() async {
    final userId = AuthService.currentUserId;
    if (userId == null) {
      return Result.error('Giriş yapmalısınız');
    }
    return await getUserStats(userId);
  }

  // ========== AYARLAR ==========

  /// Kullanıcı ayarlarını getir
  Future<Result<Map<String, dynamic>>> getUserSettings(String userId) async {
    try {
      final user = await getUser(userId);
      if (!user.isSuccess) {
        return Result.error(user.error ?? 'Kullanıcı bulunamadı');
      }

      // Default settings
      final defaultSettings = {
        'notifications': {
          'email': true,
          'push': true,
          'messages': true,
          'likes': true,
          'comments': true,
          'follows': true,
        },
        'privacy': {
          'showEmail': false,
          'showPhone': false,
          'showOnlineStatus': true,
        },
        'language': 'tr',
        'theme': 'light',
      };

      // TODO: UserModel'e settings field eklenince burası güncellenecek
      return Result.success(defaultSettings);
    } catch (e) {
      return Result.error('Ayarlar yüklenirken hata: ${e.toString()}');
    }
  }

  /// Kullanıcı ayarlarını güncelle
  Future<Result<void>> updateUserSettings(
    String userId,
    Map<String, dynamic> settings,
  ) async {
    try {
      final currentUserId = AuthService.currentUserId;
      if (currentUserId == null) {
        return Result.error('Giriş yapmalısınız');
      }

      if (currentUserId != userId) {
        return Result.error('Bu işlem için yetkiniz yok');
      }

      await _db.collection(AppConstants.collectionUsers).doc(userId).update({
        'settings': settings,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      return Result.success(null);
    } catch (e) {
      return Result.error('Ayarlar güncellenirken hata: ${e.toString()}');
    }
  }

  /// Bildirim ayarlarını güncelle
  Future<Result<void>> updateNotificationSettings(
    String userId,
    Map<String, bool> notificationSettings,
  ) async {
    try {
      final currentSettings = await getUserSettings(userId);
      if (!currentSettings.isSuccess) {
        return Result.error(currentSettings.error ?? 'Ayarlar yüklenemedi');
      }

      final settings = currentSettings.data!;
      settings['notifications'] = notificationSettings;

      return await updateUserSettings(userId, settings);
    } catch (e) {
      return Result.error('Bildirim ayarları güncellenirken hata: ${e.toString()}');
    }
  }

  /// Gizlilik ayarlarını güncelle
  Future<Result<void>> updatePrivacySettings(
    String userId,
    Map<String, bool> privacySettings,
  ) async {
    try {
      final currentSettings = await getUserSettings(userId);
      if (!currentSettings.isSuccess) {
        return Result.error(currentSettings.error ?? 'Ayarlar yüklenemedi');
      }

      final settings = currentSettings.data!;
      settings['privacy'] = privacySettings;

      return await updateUserSettings(userId, settings);
    } catch (e) {
      return Result.error('Gizlilik ayarları güncellenirken hata: ${e.toString()}');
    }
  }

  // ========== HESAP İŞLEMLERİ ==========

  /// Hesabı iş hesabına dönüştür
  Future<Result<void>> convertToBusinessAccount(String userId) async {
    try {
      final currentUserId = AuthService.currentUserId;
      if (currentUserId == null) {
        return Result.error('Giriş yapmalısınız');
      }

      if (currentUserId != userId) {
        return Result.error('Bu işlem için yetkiniz yok');
      }

      await _db.collection(AppConstants.collectionUsers).doc(userId).update({
        'isBusinessAccount': true,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      return Result.success(null);
    } catch (e) {
      return Result.error('Hesap dönüştürülürken hata: ${e.toString()}');
    }
  }

  /// Rozet ekle
  Future<Result<void>> addBadge(String userId, String badgeType) async {
    try {
      await _db.collection(AppConstants.collectionUsers).doc(userId).update({
        'badges': FieldValue.arrayUnion([badgeType]),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      return Result.success(null);
    } catch (e) {
      return Result.error('Rozet eklenirken hata: ${e.toString()}');
    }
  }

  /// Rozet kaldır
  Future<Result<void>> removeBadge(String userId, String badgeType) async {
    try {
      await _db.collection(AppConstants.collectionUsers).doc(userId).update({
        'badges': FieldValue.arrayRemove([badgeType]),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      return Result.success(null);
    } catch (e) {
      return Result.error('Rozet kaldırılırken hata: ${e.toString()}');
    }
  }

  // ========== ARAMA & LİSTELEME ==========

  /// Kullanıcı ara (isim, email)
  Future<Result<List<UserModel>>> searchUsers(String query) async {
    try {
      if (query.isEmpty) {
        return Result.success([]);
      }

      // Firestore'da contains yok, starts with kullanıyoruz
      final snapshot = await _db
          .collection(AppConstants.collectionUsers)
          .where('name', isGreaterThanOrEqualTo: query)
          .where('name', isLessThanOrEqualTo: '$query\uf8ff')
          .limit(20)
          .get();

      final users = snapshot.docs
          .map((doc) => UserModel.fromFirestore(doc))
          .toList();

      return Result.success(users);
    } catch (e) {
      return Result.error('Arama yapılırken hata: ${e.toString()}');
    }
  }

  /// En aktif kullanıcılar
  Future<Result<List<UserModel>>> getTopUsers({int limit = 10}) async {
    try {
      final snapshot = await _db
          .collection(AppConstants.collectionUsers)
          .orderBy('totalAds', descending: true)
          .limit(limit)
          .get();

      final users = snapshot.docs
          .map((doc) => UserModel.fromFirestore(doc))
          .toList();

      return Result.success(users);
    } catch (e) {
      return Result.error('Kullanıcılar yüklenirken hata: ${e.toString()}');
    }
  }

  // ========== HESAP SİLME ==========

  /// Hesabı sil (dikkatli!)
  Future<Result<void>> deleteAccount(String userId) async {
    try {
      final currentUserId = AuthService.currentUserId;
      if (currentUserId == null) {
        return Result.error('Giriş yapmalısınız');
      }

      if (currentUserId != userId) {
        return Result.error('Bu işlem için yetkiniz yok');
      }

      // TODO: İlişkili verileri de sil (ilanlar, mesajlar, vs.)
      // Bu büyük bir işlem, dikkatli yapılmalı

      await _db.collection(AppConstants.collectionUsers).doc(userId).delete();

      return Result.success(null);
    } catch (e) {
      return Result.error('Hesap silinirken hata: ${e.toString()}');
    }
  }
}
