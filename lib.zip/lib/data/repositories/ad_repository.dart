import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/utils/result.dart';
import '../../core/constants/app_constants.dart';
import '../models/ad_model.dart';
import '../../services/auth_service.dart';
import '../../services/notification_service.dart';
import 'token_repository.dart';
import 'user_repository.dart';

/// İlan işlemlerini yöneten Repository (COMPLETE VERSION)
/// Marketplace'in kalbi - tüm ilan özellikleri burada
class AdRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final TokenRepository _tokenRepository;
  final UserRepository _userRepository;
  
  AdRepository({
    TokenRepository? tokenRepository,
    UserRepository? userRepository,
  })  : _tokenRepository = tokenRepository ?? TokenRepository(),
        _userRepository = userRepository ?? UserRepository();

  // ========== İLAN OLUŞTURMA ==========

  /// İlan oluştur (Token kontrolü + Validasyon)
  Future<Result<String>> createAd({
    required String title,
    required String description,
    required double price,
    required String category,
    required String city,
    List<String>? images,
    String? mainImage,
    Map<String, dynamic>? additionalInfo,
    bool hidePriceWithToken = false,
  }) async {
    try {
      final userId = AuthService.currentUserId;
      if (userId == null) {
        return Result.error('Giriş yapmalısınız');
      }

      // Validasyon
      if (title.trim().isEmpty) {
        return Result.error('İlan başlığı boş olamaz');
      }

      if (title.length > AppConstants.maxAdTitleLength) {
        return Result.error('Başlık maksimum ${AppConstants.maxAdTitleLength} karakter olabilir');
      }

      if (description.trim().isEmpty) {
        return Result.error('İlan açıklaması boş olamaz');
      }

      if (description.length > AppConstants.maxAdDescriptionLength) {
        return Result.error('Açıklama maksimum ${AppConstants.maxAdDescriptionLength} karakter olabilir');
      }

      if (price < AppConstants.minAdPrice || price > AppConstants.maxAdPrice) {
        return Result.error('Fiyat ${AppConstants.minAdPrice} ile ${AppConstants.maxAdPrice} arasında olmalı');
      }

      if (images != null && images.length > AppConstants.maxAdImages) {
        return Result.error('Maksimum ${AppConstants.maxAdImages} resim eklenebilir');
      }

      // Token kontrolü (normal ilan)
      int requiredTokens = AppConstants.tokenPerAdCreate;
      
      // Fiyat gizleme için ekstra token
      if (hidePriceWithToken) {
        requiredTokens += 5; // +5 token fiyat gizleme için
      }

      final hasEnough = await _tokenRepository.hasEnoughTokens(userId, requiredTokens);
      if (!hasEnough) {
        return Result.error('Yetersiz token. $requiredTokens token gerekli.');
      }

      // Kullanıcı bilgisi
      final userResult = await _userRepository.getUser(userId);
      if (!userResult.isSuccess) {
        return Result.error('Kullanıcı bilgisi alınamadı');
      }

      final user = userResult.data!;

      // İlan verisi
      final adData = {
        'userId': userId,
        'userName': user.name,
        'userPhotoUrl': user.photoUrl,
        'title': title.trim(),
        'description': description.trim(),
        'price': price,
        'priceHidden': hidePriceWithToken,
        'category': category,
        'city': city,
        'images': images ?? [],
        'mainImage': mainImage ?? (images?.isNotEmpty == true ? images!.first : null),
        'status': 'active',
        'viewCount': 0,
        'favoriteCount': 0,
        'messageCount': 0,
        'isFeatured': false,
        'featuredUntil': null,
        'additionalInfo': additionalInfo ?? {},
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      };

      // İlan oluştur
      final adDoc = await _db.collection(AppConstants.collectionAds).add(adData);

      // Token düş
      await _tokenRepository.deductTokens(
        userId,
        requiredTokens,
        reason: 'İlan oluşturma${hidePriceWithToken ? ' (fiyat gizli)' : ''}',
        metadata: {'adId': adDoc.id},
      );

      return Result.success(adDoc.id);
    } catch (e) {
      return Result.error('İlan oluşturulurken hata: ${e.toString()}');
    }
  }

  // ========== İLAN GÜNCELLEME ==========

  /// İlan güncelle
  Future<Result<void>> updateAd({
    required String adId,
    String? title,
    String? description,
    double? price,
    String? category,
    String? city,
    List<String>? images,
    String? mainImage,
    Map<String, dynamic>? additionalInfo,
  }) async {
    try {
      final userId = AuthService.currentUserId;
      if (userId == null) {
        return Result.error('Giriş yapmalısınız');
      }

      // İlan sahibi kontrolü
      final adResult = await getAd(adId);
      if (!adResult.isSuccess) {
        return Result.error(adResult.error ?? 'İlan bulunamadı');
      }

      final ad = adResult.data!;
      if (ad.userId != userId) {
        return Result.error('Bu ilanı düzenleme yetkiniz yok');
      }

      // Güncelleme verisi
      final updateData = <String, dynamic>{};

      if (title != null) {
        if (title.trim().isEmpty) {
          return Result.error('İlan başlığı boş olamaz');
        }
        updateData['title'] = title.trim();
      }

      if (description != null) {
        if (description.trim().isEmpty) {
          return Result.error('İlan açıklaması boş olamaz');
        }
        updateData['description'] = description.trim();
      }

      if (price != null) {
        if (price < AppConstants.minAdPrice || price > AppConstants.maxAdPrice) {
          return Result.error('Fiyat geçersiz');
        }
        updateData['price'] = price;
      }

      if (category != null) updateData['category'] = category;
      if (city != null) updateData['city'] = city;
      if (images != null) updateData['images'] = images;
      if (mainImage != null) updateData['mainImage'] = mainImage;
      if (additionalInfo != null) updateData['additionalInfo'] = additionalInfo;

      updateData['updatedAt'] = FieldValue.serverTimestamp();

      await _db.collection(AppConstants.collectionAds).doc(adId).update(updateData);

      return Result.success(null);
    } catch (e) {
      return Result.error('İlan güncellenirken hata: ${e.toString()}');
    }
  }

  // ========== İLAN SİLME ==========

  /// İlan sil
  Future<Result<void>> deleteAd(String adId) async {
    try {
      final userId = AuthService.currentUserId;
      if (userId == null) {
        return Result.error('Giriş yapmalısınız');
      }

      // İlan sahibi kontrolü
      final adResult = await getAd(adId);
      if (!adResult.isSuccess) {
        return Result.error(adResult.error ?? 'İlan bulunamadı');
      }

      final ad = adResult.data!;
      if (ad.userId != userId) {
        return Result.error('Bu ilanı silme yetkiniz yok');
      }

      // İlanı sil
      await _db.collection(AppConstants.collectionAds).doc(adId).delete();

      // TODO: İlgili favorileri, mesajları, görüntüleme kayıtlarını da sil

      return Result.success(null);
    } catch (e) {
      return Result.error('İlan silinirken hata: ${e.toString()}');
    }
  }

  /// İlan durumunu değiştir (active, sold, inactive)
  Future<Result<void>> changeAdStatus(String adId, String status) async {
    try {
      final userId = AuthService.currentUserId;
      if (userId == null) {
        return Result.error('Giriş yapmalısınız');
      }

      // İlan sahibi kontrolü
      final adResult = await getAd(adId);
      if (!adResult.isSuccess) {
        return Result.error(adResult.error ?? 'İlan bulunamadı');
      }

      if (adResult.data!.userId != userId) {
        return Result.error('Bu işlem için yetkiniz yok');
      }

      // Durum kontrolü
      if (!['active', 'sold', 'inactive'].contains(status)) {
        return Result.error('Geçersiz durum');
      }

      await _db.collection(AppConstants.collectionAds).doc(adId).update({
        'status': status,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      return Result.success(null);
    } catch (e) {
      return Result.error('Durum değiştirilirken hata: ${e.toString()}');
    }
  }

  // ========== İLAN OKUMA ==========

  /// İlan detayı getir (görüntülenme kaydı ile)
  Future<Result<AdModel>> getAd(String adId) async {
    try {
      final adDoc = await _db.collection(AppConstants.collectionAds).doc(adId).get();

      if (!adDoc.exists) {
        return Result.error('İlan bulunamadı');
      }

      final ad = AdModel.fromFirestore(adDoc);

      // Görüntülenme kaydet (kendi ilanı değilse)
      final userId = AuthService.currentUserId;
      if (userId != null && userId != ad.userId) {
        await _recordAdView(adId, userId);
      }

      return Result.success(ad);
    } catch (e) {
      return Result.error('İlan yüklenirken hata: ${e.toString()}');
    }
  }

  /// Görüntülenme kaydet (private)
  Future<void> _recordAdView(String adId, String userId) async {
    try {
      // Görüntülenme sayısını artır
      await _db.collection(AppConstants.collectionAds).doc(adId).update({
        'viewCount': FieldValue.increment(1),
      });

      // Görüntüleme geçmişine ekle
      await _db
          .collection(AppConstants.collectionViewHistory)
          .doc(userId)
          .collection('ads')
          .doc(adId)
          .set({
        'viewedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      // Görüntüleme kaydı hatası uygulamayı durdurmamalı
      print('Görüntüleme kaydedilemedi: $e');
    }
  }

  // ========== İLAN LİSTELEME ==========

  /// Tüm ilanları getir (Stream)
  Stream<List<AdModel>> getAds({
    String? category,
    String? city,
    double? minPrice,
    double? maxPrice,
    String? status,
    int limit = 20,
  }) {
    Query query = _db.collection(AppConstants.collectionAds);

    // Filtreler
    if (status != null) {
      query = query.where('status', isEqualTo: status);
    } else {
      query = query.where('status', isEqualTo: 'active');
    }

    if (category != null) {
      query = query.where('category', isEqualTo: category);
    }

    if (city != null) {
      query = query.where('city', isEqualTo: city);
    }

    if (minPrice != null) {
      query = query.where('price', isGreaterThanOrEqualTo: minPrice);
    }

    if (maxPrice != null) {
      query = query.where('price', isLessThanOrEqualTo: maxPrice);
    }

    return query
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => AdModel.fromFirestore(doc)).toList());
  }

  /// Kullanıcının ilanlarını getir
  Stream<List<AdModel>> getUserAds(String userId, {String? status}) {
    Query query = _db
        .collection(AppConstants.collectionAds)
        .where('userId', isEqualTo: userId);

    if (status != null) {
      query = query.where('status', isEqualTo: status);
    }

    return query
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => AdModel.fromFirestore(doc)).toList());
  }

  /// Popüler ilanları getir (görüntülenme bazlı)
  Stream<List<AdModel>> getPopularAds({int limit = 10}) {
    return _db
        .collection(AppConstants.collectionAds)
        .where('status', isEqualTo: 'active')
        .orderBy('viewCount', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => AdModel.fromFirestore(doc)).toList());
  }

  /// Öne çıkan ilanları getir
  Stream<List<AdModel>> getFeaturedAds({int limit = 5}) {
    final now = DateTime.now();
    
    return _db
        .collection(AppConstants.collectionAds)
        .where('status', isEqualTo: 'active')
        .where('isFeatured', isEqualTo: true)
        .where('featuredUntil', isGreaterThan: Timestamp.fromDate(now))
        .orderBy('featuredUntil', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => AdModel.fromFirestore(doc)).toList());
  }

  // ========== İLAN ARAMA ==========

  /// İlan ara (başlık, açıklama)
  Future<Result<List<AdModel>>> searchAds(String query) async {
    try {
      if (query.trim().isEmpty) {
        return Result.success([]);
      }

      // Firestore'da full-text search yok
      // Başlık bazlı basit arama
      final snapshot = await _db
          .collection(AppConstants.collectionAds)
          .where('status', isEqualTo: 'active')
          .where('title', isGreaterThanOrEqualTo: query)
          .where('title', isLessThanOrEqualTo: '$query\uf8ff')
          .limit(20)
          .get();

      final ads = snapshot.docs.map((doc) => AdModel.fromFirestore(doc)).toList();

      return Result.success(ads);
    } catch (e) {
      return Result.error('Arama yapılırken hata: ${e.toString()}');
    }
  }

  // ========== FAVORİ İŞLEMLERİ ==========

  /// İlanı favorilere ekle/çıkar (Token kontrolü)
  Future<Result<void>> toggleFavorite(String adId) async {
    try {
      final userId = AuthService.currentUserId;
      if (userId == null) {
        return Result.error('Giriş yapmalısınız');
      }

      final isFavorite = await isAdInFavorites(adId, userId);

      if (!isFavorite) {
        // Favoriye eklerken token kontrolü
        final hasEnough = await _tokenRepository.hasEnoughTokens(
          userId,
          AppConstants.tokenPerLike,
        );

        if (!hasEnough) {
          return Result.error(
            'Yetersiz token. Favori eklemek için ${AppConstants.tokenPerLike} token gerekli.',
          );
        }

        // Favoriye ekle
        await _db
            .collection(AppConstants.collectionUsers)
            .doc(userId)
            .collection('favorites')
            .doc(adId)
            .set({'addedAt': FieldValue.serverTimestamp()});

        // Favori sayısını artır
        await _db.collection(AppConstants.collectionAds).doc(adId).update({
          'favoriteCount': FieldValue.increment(1),
        });

        // Token düş
        await _tokenRepository.deductTokens(
          userId,
          AppConstants.tokenPerLike,
          reason: 'İlan favorileme',
          metadata: {'adId': adId},
        );
      } else {
        // Favoriden çıkar
        await _db
            .collection(AppConstants.collectionUsers)
            .doc(userId)
            .collection('favorites')
            .doc(adId)
            .delete();

        // Favori sayısını azalt
        await _db.collection(AppConstants.collectionAds).doc(adId).update({
          'favoriteCount': FieldValue.increment(-1),
        });

        // Token iade et
        await _tokenRepository.addTokens(
          userId,
          AppConstants.tokenPerLike,
          reason: 'Favori kaldırma',
          metadata: {'adId': adId},
        );
      }

      return Result.success(null);
    } catch (e) {
      return Result.error('Favori işlemi başarısız: ${e.toString()}');
    }
  }

  /// İlan favorilerde mi?
  Future<bool> isAdInFavorites(String adId, String userId) async {
    try {
      final doc = await _db
          .collection(AppConstants.collectionUsers)
          .doc(userId)
          .collection('favorites')
          .doc(adId)
          .get();

      return doc.exists;
    } catch (e) {
      return false;
    }
  }

  /// Favori ilanları getir (Stream)
  Stream<List<AdModel>> getFavoriteAds(String userId) {
    return _db
        .collection(AppConstants.collectionUsers)
        .doc(userId)
        .collection('favorites')
        .orderBy('addedAt', descending: true)
        .snapshots()
        .asyncMap((snapshot) async {
      final adIds = snapshot.docs.map((doc) => doc.id).toList();
      
      if (adIds.isEmpty) return <AdModel>[];

      // Firestore 'in' query limiti 10
      if (adIds.length > 10) {
        adIds.removeRange(10, adIds.length);
      }

      final adsSnapshot = await _db
          .collection(AppConstants.collectionAds)
          .where(FieldPath.documentId, whereIn: adIds)
          .get();

      return adsSnapshot.docs
          .map((doc) => AdModel.fromFirestore(doc))
          .toList();
    });
  }

  // ========== ÖZEL ÖZELLİKLER ==========

  /// İlanı öne çıkar (Token ile)
  Future<Result<void>> featureAd(String adId, int days) async {
    try {
      final userId = AuthService.currentUserId;
      if (userId == null) {
        return Result.error('Giriş yapmalısınız');
      }

      // İlan sahibi kontrolü
      final adResult = await getAd(adId);
      if (!adResult.isSuccess) {
        return Result.error(adResult.error ?? 'İlan bulunamadı');
      }

      if (adResult.data!.userId != userId) {
        return Result.error('Bu işlem için yetkiniz yok');
      }

      // Token hesaplama (gün başına 20 token)
      final requiredTokens = AppConstants.tokenPerAdFeatured * days;

      final hasEnough = await _tokenRepository.hasEnoughTokens(userId, requiredTokens);
      if (!hasEnough) {
        return Result.error('Yetersiz token. $requiredTokens token gerekli.');
      }

      // Öne çıkarma süresi hesapla
      final featuredUntil = DateTime.now().add(Duration(days: days));

      // İlanı öne çıkar
      await _db.collection(AppConstants.collectionAds).doc(adId).update({
        'isFeatured': true,
        'featuredUntil': Timestamp.fromDate(featuredUntil),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      // Token düş
      await _tokenRepository.deductTokens(
        userId,
        requiredTokens,
        reason: 'İlan öne çıkarma ($days gün)',
        metadata: {'adId': adId, 'days': days},
      );

      return Result.success(null);
    } catch (e) {
      return Result.error('İlan öne çıkarılırken hata: ${e.toString()}');
    }
  }

  /// Fiyatı göster/gizle (Token ile)
  Future<Result<void>> togglePriceVisibility(String adId) async {
    try {
      final userId = AuthService.currentUserId;
      if (userId == null) {
        return Result.error('Giriş yapmalısınız');
      }

      // İlan sahibi kontrolü
      final adResult = await getAd(adId);
      if (!adResult.isSuccess) {
        return Result.error(adResult.error ?? 'İlan bulunamadı');
      }

      final ad = adResult.data!;
      if (ad.userId != userId) {
        return Result.error('Bu işlem için yetkiniz yok');
      }

      final currentlyHidden = ad.priceHidden ?? false;
      
      // Fiyat gizleniyorsa göster (ücretsiz)
      // Fiyat gösteriyorsa gizle (5 token)
      if (!currentlyHidden) {
        // Gizleme işlemi - token kontrolü
        final hasEnough = await _tokenRepository.hasEnoughTokens(userId, 5);
        if (!hasEnough) {
          return Result.error('Yetersiz token. Fiyat gizlemek için 5 token gerekli.');
        }

        await _tokenRepository.deductTokens(
          userId,
          5,
          reason: 'Fiyat gizleme',
          metadata: {'adId': adId},
        );
      }

      // Durumu değiştir
      await _db.collection(AppConstants.collectionAds).doc(adId).update({
        'priceHidden': !currentlyHidden,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      return Result.success(null);
    } catch (e) {
      return Result.error('Fiyat görünürlüğü değiştirilirken hata: ${e.toString()}');
    }
  }

  // ========== İSTATİSTİKLER ==========

  /// İlan istatistiklerini getir
  Future<Result<Map<String, dynamic>>> getAdStats(String adId) async {
    try {
      final adResult = await getAd(adId);
      if (!adResult.isSuccess) {
        return Result.error(adResult.error ?? 'İlan bulunamadı');
      }

      final ad = adResult.data!;

      // Mesaj sayısı
      final messagesSnapshot = await _db
          .collection(AppConstants.collectionChats)
          .where('adId', isEqualTo: adId)
          .get();

      final stats = {
        'adId': adId,
        'viewCount': ad.viewCount ?? 0,
        'favoriteCount': ad.favoriteCount ?? 0,
        'messageCount': messagesSnapshot.docs.length,
        'status': ad.status,
        'isFeatured': ad.isFeatured,
        'createdAt': ad.createdAt,
      };

      return Result.success(stats);
    } catch (e) {
      return Result.error('İstatistikler yüklenirken hata: ${e.toString()}');
    }
  }

  /// Kullanıcı ilan istatistikleri
  Future<Result<Map<String, dynamic>>> getUserAdStats(String userId) async {
    try {
      final adsSnapshot = await _db
          .collection(AppConstants.collectionAds)
          .where('userId', isEqualTo: userId)
          .get();

      int activeAds = 0;
      int soldAds = 0;
      int totalViews = 0;
      int totalFavorites = 0;

      for (var doc in adsSnapshot.docs) {
        final data = doc.data();
        final status = data['status'] as String?;

        if (status == 'active') activeAds++;
        if (status == 'sold') soldAds++;

        totalViews += (data['viewCount'] ?? 0) as int;
        totalFavorites += (data['favoriteCount'] ?? 0) as int;
      }

      final stats = {
        'totalAds': adsSnapshot.docs.length,
        'activeAds': activeAds,
        'soldAds': soldAds,
        'totalViews': totalViews,
        'totalFavorites': totalFavorites,
        'averageViews': adsSnapshot.docs.isEmpty ? 0 : totalViews / adsSnapshot.docs.length,
      };

      return Result.success(stats);
    } catch (e) {
      return Result.error('İstatistikler hesaplanırken hata: ${e.toString()}');
    }
  }
}
