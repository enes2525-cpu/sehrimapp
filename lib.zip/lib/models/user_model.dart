import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String id;
  final String email;
  final String name;
  final String? phone;
  final String? photoUrl;
  final String? city;
  final String? district;
  final bool isBusinessAccount;
  final int tokenBalance;
  final int totalAds;
  final int totalSales;
  final double rating;
  final int reviewCount;
  final List<String> badges; // rozetler: 'fast_reply', 'trusted_seller', etc.
  final DateTime createdAt;
  final DateTime lastActive;

  UserModel({
    required this.id,
    required this.email,
    required this.name,
    this.phone,
    this.photoUrl,
    this.city,
    this.district,
    this.isBusinessAccount = false,
    this.tokenBalance = 100, // Başlangıç token'ı
    this.totalAds = 0,
    this.totalSales = 0,
    this.rating = 5.0,
    this.reviewCount = 0,
    List<String>? badges,
    DateTime? createdAt,
    DateTime? lastActive,
  })  : badges = badges ?? [],
        createdAt = createdAt ?? DateTime.now(),
        lastActive = lastActive ?? DateTime.now();

  // Firestore'dan veri çekme
  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      id: doc.id,
      email: data['email'] ?? '',
      name: data['name'] ?? '',
      phone: data['phone'],
      photoUrl: data['photoUrl'],
      city: data['city'],
      district: data['district'],
      isBusinessAccount: data['isBusinessAccount'] ?? false,
      tokenBalance: data['tokenBalance'] ?? 100,
      totalAds: data['totalAds'] ?? 0,
      totalSales: data['totalSales'] ?? 0,
      rating: (data['rating'] ?? 5.0).toDouble(),
      reviewCount: data['reviewCount'] ?? 0,
      badges: data['badges'] != null ? List<String>.from(data['badges']) : [],
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      lastActive: (data['lastActive'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  // Firestore'a kaydetme
  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'name': name,
      'phone': phone,
      'photoUrl': photoUrl,
      'city': city,
      'district': district,
      'isBusinessAccount': isBusinessAccount,
      'tokenBalance': tokenBalance,
      'totalAds': totalAds,
      'totalSales': totalSales,
      'rating': rating,
      'reviewCount': reviewCount,
      'badges': badges,
      'createdAt': Timestamp.fromDate(createdAt),
      'lastActive': FieldValue.serverTimestamp(),
    };
  }

  // Token ekle/çıkar
  UserModel updateTokenBalance(int amount) {
    return UserModel(
      id: id,
      email: email,
      name: name,
      phone: phone,
      photoUrl: photoUrl,
      city: city,
      district: district,
      isBusinessAccount: isBusinessAccount,
      tokenBalance: tokenBalance + amount,
      totalAds: totalAds,
      totalSales: totalSales,
      rating: rating,
      reviewCount: reviewCount,
      badges: badges,
      createdAt: createdAt,
      lastActive: DateTime.now(),
    );
  }

  // Rozet ekle
  UserModel addBadge(String badge) {
    if (badges.contains(badge)) return this;
    return UserModel(
      id: id,
      email: email,
      name: name,
      phone: phone,
      photoUrl: photoUrl,
      city: city,
      district: district,
      isBusinessAccount: isBusinessAccount,
      tokenBalance: tokenBalance,
      totalAds: totalAds,
      totalSales: totalSales,
      rating: rating,
      reviewCount: reviewCount,
      badges: [...badges, badge],
      createdAt: createdAt,
      lastActive: DateTime.now(),
    );
  }

  // Yeterli token var mı?
  bool hasEnoughTokens(int required) => tokenBalance >= required;

  // Rozete sahip mi?
  bool hasBadge(String badge) => badges.contains(badge);

  // Kullanıcı adını kısalt (Mehmet A. gibi)
  String get shortName {
    final parts = name.split(' ');
    if (parts.length > 1) {
      return '${parts[0]} ${parts[1][0]}.';
    }
    return name;
  }
}
