import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io';
import '../../models/ad_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../services/auth_service.dart';
import '../../widgets/badge_widget.dart';
import '../conversations/chat_screen.dart';
import '../report/report_screen.dart';

class AdDetailScreen extends StatefulWidget {
  final String adId;

  const AdDetailScreen({Key? key, required this.adId}) : super(key: key);

  @override
  State<AdDetailScreen> createState() => _AdDetailScreenState();
}

class _AdDetailScreenState extends State<AdDetailScreen> {
  bool _isFavorite = false;
  bool _isLoading = true;
  AdModel? _ad;
  UserModel? _seller;

  @override
  void initState() {
    super.initState();
    _loadAdDetails();
  }

  Future<void> _loadAdDetails() async {
    try {
      // İlanı getir
      final ad = await FirestoreService.getAd(widget.adId);
      if (ad == null) {
        if (mounted) {
          Navigator.pop(context);
          _showSnackBar('İlan bulunamadı');
        }
        return;
      }

      // Görüntülenme sayısını artır
      await FirestoreService.incrementAdViews(widget.adId);

      // Satıcı bilgilerini getir
      final seller = await FirestoreService.getUser(ad.userId);

      // Favori durumunu kontrol et
      final userId = AuthService.currentUserId;
      bool isFav = false;
      if (userId != null) {
        isFav = await FirestoreService.isAdFavorite(userId, widget.adId);
      }

      if (mounted) {
        setState(() {
          _ad = ad;
          _seller = seller;
          _isFavorite = isFav;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        _showSnackBar('Hata: $e');
      }
    }
  }

  Future<void> _toggleFavorite() async {
    final userId = AuthService.currentUserId;
    if (userId == null) {
      _showSnackBar('Favorilere eklemek için giriş yapın');
      return;
    }

    setState(() => _isFavorite = !_isFavorite);

    try {
      if (_isFavorite) {
        await FirestoreService.addToFavorites(userId, widget.adId);
        _showSnackBar('Favorilere eklendi');
      } else {
        await FirestoreService.removeFromFavorites(userId, widget.adId);
        _showSnackBar('Favorilerden çıkarıldı');
      }
    } catch (e) {
      setState(() => _isFavorite = !_isFavorite);
      _showSnackBar('Hata: $e');
    }
  }

  Future<void> _makePhoneCall(String phone) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: phone);
    if (await canLaunchUrl(phoneUri)) {
      await launchUrl(phoneUri);
    } else {
      _showSnackBar('Telefon araması yapılamıyor');
    }
  }

  void _openChat() {
    if (_ad == null || _seller == null) return;

    final userId = AuthService.currentUserId;
    if (userId == null) {
      _showSnackBar('Mesaj göndermek için giriş yapın');
      return;
    }

    if (userId == _ad!.userId) {
      _showSnackBar('Kendi ilanınıza mesaj gönderemezsiniz');
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChatScreen(
          chatId: '${_ad!.id}_$userId',
          adId: _ad!.id,
          adTitle: _ad!.title,
          otherUserId: _ad!.userId,
          otherUserName: _seller!.name,
        ),
      ),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (_ad == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: Text('İlan bulunamadı')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('İlan Detayı'),
        actions: [
          IconButton(
            icon: Icon(
              _isFavorite ? Icons.favorite : Icons.favorite_border,
              color: _isFavorite ? Colors.red : null,
            ),
            onPressed: _toggleFavorite,
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'report') {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ReportScreen(
                      reportedId: widget.adId,
                      reportType: 'ad',
                      reportedName: _ad?.title ?? 'İlan',
                    ),
                  ),
                );
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'report',
                child: Row(
                  children: [
                    Icon(Icons.flag, color: Colors.red),
                    SizedBox(width: 8),
                    Text('İlanı Raporla'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildImageGallery(),
                  _buildAdInfo(),
                  const Divider(height: 32),
                  _buildSellerInfo(),
                  const SizedBox(height: 80),
                ],
              ),
            ),
          ),
          _buildBottomBar(),
        ],
      ),
    );
  }

  Widget _buildImageGallery() {
    final images = _ad!.images;
    if (images.isEmpty) {
      return Container(
        height: 300,
        color: Colors.grey[200],
        child: const Center(
          child: Icon(Icons.image_not_supported, size: 64, color: Colors.grey),
        ),
      );
    }

    return SizedBox(
      height: 300,
      child: PageView.builder(
        itemCount: images.length,
        itemBuilder: (context, index) {
          final imagePath = images[index];
          
          // Local dosya mı kontrol et
          if (imagePath.startsWith('/') || imagePath.startsWith('file://')) {
            return Image.file(
              File(imagePath),
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return const Center(
                  child: Icon(Icons.broken_image, size: 64, color: Colors.grey),
                );
              },
            );
          }
          
          // Network image (Firebase Storage URL'si olabilir)
          return CachedNetworkImage(
            imageUrl: imagePath,
            fit: BoxFit.cover,
            placeholder: (context, url) => const Center(
              child: CircularProgressIndicator(),
            ),
            errorWidget: (context, url, error) => const Icon(Icons.error),
          );
        },
      ),
    );
  }

  Widget _buildAdInfo() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Başlık ve Fiyat
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  _ad!.title,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              if (!_ad!.priceHidden)
                Text(
                  '${_ad!.price.toStringAsFixed(0)} ₺',
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),

          // Görüntülenme, Kategori, Konum
          Wrap(
            spacing: 16,
            runSpacing: 8,
            children: [
              _buildInfoChip(Icons.visibility, '${_ad!.viewCount} görüntülenme'),
              _buildInfoChip(Icons.category, _ad!.category),
              if (_ad!.subcategory != null)
                _buildInfoChip(Icons.subdirectory_arrow_right, _ad!.subcategory!),
              _buildInfoChip(Icons.location_city, _ad!.city),
              if (_ad!.district != null)
                _buildInfoChip(Icons.location_on, _ad!.district!),
            ],
          ),
          const SizedBox(height: 16),

          // Açıklama
          const Text(
            'Açıklama',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            _ad!.description,
            style: const TextStyle(fontSize: 16, height: 1.5),
          ),
          const SizedBox(height: 16),

          // Yayın Tarihi
          Text(
            'Yayınlanma: ${_formatDate(_ad!.createdAt)}',
            style: TextStyle(color: Colors.grey[600], fontSize: 14),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label) {
    return Chip(
      avatar: Icon(icon, size: 16),
      label: Text(label),
      backgroundColor: Colors.grey[100],
    );
  }

  Widget _buildSellerInfo() {
    if (_seller == null) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Satıcı Bilgileri',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey[50],
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey[200]!),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundImage: _seller!.photoUrl != null
                      ? CachedNetworkImageProvider(_seller!.photoUrl!)
                      : null,
                  child: _seller!.photoUrl == null
                      ? Text(_seller!.name[0].toUpperCase())
                      : null,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _seller!.name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Icon(Icons.star, size: 16, color: Colors.amber[700]),
                          const SizedBox(width: 4),
                          Text(
                            '${_seller!.rating.toStringAsFixed(1)} (${_seller!.reviewCount} değerlendirme)',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                      if (_seller!.badges.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Wrap(
                            spacing: 4,
                            children: List<Widget>.from(
                              _seller!.badges
                                  .take(2)
                                  .map((badge) => _buildBadge(badge)),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomBar() {
    final isOwnAd = AuthService.currentUserId == _ad!.userId;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            if (_ad!.userPhone != null && !isOwnAd)
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _makePhoneCall(_ad!.userPhone!),
                  icon: const Icon(Icons.phone),
                  label: const Text('Ara'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            if (_ad!.userPhone != null && !isOwnAd) const SizedBox(width: 12),
            if (!isOwnAd)
              Expanded(
                flex: 2,
                child: ElevatedButton.icon(
                  onPressed: _openChat,
                  icon: const Icon(Icons.message),
                  label: const Text('Mesaj Gönder'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            if (isOwnAd)
              const Expanded(
                child: Center(
                  child: Text(
                    'Bu sizin ilanınız',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final diff = now.difference(date);

    if (diff.inDays == 0) {
      if (diff.inHours == 0) {
        return '${diff.inMinutes} dakika önce';
      }
      return '${diff.inHours} saat önce';
    } else if (diff.inDays == 1) {
      return 'Dün';
    } else if (diff.inDays < 7) {
      return '${diff.inDays} gün önce';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }

  Widget _buildBadge(String badge) {
    return BadgeWidget(badgeType: badge, compact: true);
  }
}
