import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../../data/models/user_model.dart';
import '../../../data/repositories/user_repository.dart';
import '../../../data/repositories/token_repository.dart';

/// Authentication Provider
/// Giriş/Çıkış + Kullanıcı durumu yönetimi
class AuthProvider with ChangeNotifier {
  final UserRepository _userRepository = UserRepository();
  final TokenRepository _tokenRepository = TokenRepository();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  UserModel? _currentUser;
  int _tokenBalance = 0;
  bool _isLoading = false;
  String? _error;

  // Getters
  UserModel? get currentUser => _currentUser;
  int get tokenBalance => _tokenBalance;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _currentUser != null;

  AuthProvider() {
    _init();
  }

  // Initialization
  void _init() {
    _auth.authStateChanges().listen((user) {
      if (user != null) {
        _loadUserData(user.uid);
      } else {
        _currentUser = null;
        _tokenBalance = 0;
        notifyListeners();
      }
    });
  }

  // Load user data
  Future<void> _loadUserData(String userId) async {
    _isLoading = true;
    notifyListeners();

    try {
      // Load user
      final userResult = await _userRepository.getUser(userId);
      if (userResult.isSuccess) {
        _currentUser = userResult.data;

        // Load token balance
        final balanceResult = await _tokenRepository.getBalance(userId);
        if (balanceResult.isSuccess) {
          _tokenBalance = balanceResult.data!;
        }
      }

      _error = null;
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Login with email
  Future<bool> loginWithEmail(String email, String password) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return true;
    } catch (e) {
      _error = 'Giriş başarısız: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Register
  Future<bool> register(String email, String password, String name) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Create user document
      // (Bu işlem FirestoreService'de yapılmalı)

      return true;
    } catch (e) {
      _error = 'Kayıt başarısız: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Logout
  Future<void> logout() async {
    await _auth.signOut();
    _currentUser = null;
    _tokenBalance = 0;
    notifyListeners();
  }

  // Refresh user data
  Future<void> refreshUserData() async {
    if (_currentUser != null) {
      await _loadUserData(_currentUser!.id);
    }
  }

  // Refresh token balance
  Future<void> refreshTokenBalance() async {
    if (_currentUser != null) {
      final result = await _tokenRepository.getBalance(_currentUser!.id);
      if (result.isSuccess) {
        _tokenBalance = result.data!;
        notifyListeners();
      }
    }
  }
}
