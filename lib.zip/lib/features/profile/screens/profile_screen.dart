import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:sehrimapp/models/user_model.dart';
import 'package:sehrimapp/services/firestore_service.dart';
import 'package:sehrimapp/services/auth_service.dart';
import 'package:sehrimapp/screens/auth/login_screen.dart';
import 'package:sehrimapp/screens/my_ads/my_ads_screen.dart';
import 'package:sehrimapp/screens/favorites/favorites_screen.dart';
import 'package:sehrimapp/screens/token/token_wallet_screen.dart';
import 'package:sehrimapp/screens/shop/shop_management_screen.dart';
import 'package:sehrimapp/screens/referral/referral_screen.dart';
import 'package:sehrimapp/widgets/badge_widget.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  UserModel? _user;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final userId = AuthService.currentUserId;
    if (userId == null) {
      setState(() => _loading = false);
      return;
    }

    try {
      final user = await FirestoreService.getUser(userId);
      if (mounted) {
        setState(() {
          _user = user;
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  Future<void> _signOut() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Çıkış Yap'),
        content: const Text('Çıkış yapmak istediğinize emin misiniz?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('İptal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Çıkış Yap', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await FirebaseAuth.instance.signOut();
      if (mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => const LoginScreen()),
          (route) => false,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (_user == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Profil')),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.person_off, size: 80, color: Colors.grey),
              const SizedBox(height: 16),
              const Text('Kullanıcı bilgisi yüklenemedi'),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => const LoginScreen()),
                    (route) => false,
                  );
                },
                child: const Text('Giriş Yap'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _signOut,
            tooltip: 'Çıkış Yap',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadUserData,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              // Profil Başlığı
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Theme.of(context).primaryColor,
                      Theme.of(context).primaryColor.withOpacity(0.7),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Column(
                  children: [
                    // Avatar
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.white,
                      child: _user!.photoUrl != null
                          ? ClipOval(
                              child: Image.network(
                                _user!.photoUrl!,
                                width: 100,
                                height: 100,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  return Text(
                                    _user!.name[0].toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 40,
                                      color: Theme.of(context).primaryColor,
                                    ),
                                  );
                                },
                              ),
                            )
                          : Text(
                              _user!.name[0].toUpperCase(),
                              style: TextStyle(
                                fontSize: 40,
                                color: Theme.of(context).primaryColor,
                              ),
                            ),
                    ),
                    const SizedBox(height: 16),
                    // İsim
                    Text(
                      _user!.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    // Email
                    Text(
                      _user!.email,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                    // Rozetler
                    if (_user!.badges.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        children: _user!.badges.take(3).map((badge) {
                          return BadgeWidget(badgeType: badge, compact: true);
                        }).toList(),
                      ),
                    ],
                    const SizedBox(height: 16),
                    // İstatistikler
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildStatItem('İlanlar', '${_user!.totalAds}'),
                        _buildStatItem('Token', '${_user!.tokenBalance}'),
                        _buildStatItem('Puan', _user!.rating.toStringAsFixed(1)),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // Menü Listesi
              _buildMenuItem(
                icon: Icons.article,
                title: 'İlanlarım',
                subtitle: '${_user!.totalAds} aktif ilan',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const MyAdsScreen(),
                    ),
                  );
                },
              ),
              _buildMenuItem(
                icon: Icons.favorite,
                title: 'Favorilerim',
                subtitle: 'Beğendiğin ilanlar',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const FavoritesScreen(),
                    ),
                  );
                },
              ),
              _buildMenuItem(
                icon: Icons.account_balance_wallet,
                title: 'Token Cüzdanım',
                subtitle: '${_user!.tokenBalance} token',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TokenWalletScreen(),
                    ),
                  );
                },
              ),
              if (_user!.isBusinessAccount)
                _buildMenuItem(
                  icon: Icons.store,
                  title: 'Dükkanım',
                  subtitle: 'İşletme yönetimi',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const ShopManagementScreen(),
                      ),
                    );
                  },
                ),
              _buildMenuItem(
                icon: Icons.card_giftcard,
                title: 'Arkadaşını Davet Et',
                subtitle: '50 token kazan!',
                color: Colors.orange,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ReferralScreen(),
                    ),
                  );
                },
              ),
              const Divider(height: 32),
              _buildMenuItem(
                icon: Icons.settings,
                title: 'Ayarlar',
                subtitle: 'Hesap ayarları',
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Ayarlar ekranı yakında...')),
                  );
                },
              ),
              _buildMenuItem(
                icon: Icons.help,
                title: 'Yardım & Destek',
                subtitle: 'SSS ve iletişim',
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Yardım ekranı yakında...')),
                  );
                },
              ),
              _buildMenuItem(
                icon: Icons.logout,
                title: 'Çıkış Yap',
                subtitle: 'Hesaptan çık',
                color: Colors.red,
                onTap: _signOut,
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    Color? color,
  }) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: (color ?? Colors.blue).withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: color ?? Colors.blue),
      ),
      title: Text(
        title,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          color: color,
        ),
      ),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }
}
